# Source Code Documentation

## Codebase Walkthrough - **src/components/wallet-popup/** Folder

The **src/components/wallet-popup/** folder serves as the designated repository for the primary `WalletPopup` component. This component features a button that triggers a popup modal, providing a comprehensive display of information about the connected user.
