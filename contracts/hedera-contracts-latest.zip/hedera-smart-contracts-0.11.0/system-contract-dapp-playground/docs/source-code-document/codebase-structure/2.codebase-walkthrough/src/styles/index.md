# Source Code Documentation

## Codebase Walkthrough - **src/styles/** Folder

The **src/styles/** folder serves as the repository for the global styles that define the visual appearance and consistency of the entire project.
