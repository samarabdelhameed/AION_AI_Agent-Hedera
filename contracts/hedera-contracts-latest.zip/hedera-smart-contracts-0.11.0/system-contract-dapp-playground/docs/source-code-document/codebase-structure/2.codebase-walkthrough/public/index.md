# Source code documentation

## Codebase Walkthrough - **public** folder

The main purpose of the public folder is to provide a location for files that should be accessible directly by the browser, without going through the module system or being bundled with the rest of the application code. This folder primarily contains image assets that are integral to the user interface and overall user experience of the DApp.
